package io.paint.view;

public interface AppearanceReady {
    void ready();
}

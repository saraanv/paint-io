package io.paint.data.enums;

public enum PainterType {
    HUMAN, SYSTEM
}

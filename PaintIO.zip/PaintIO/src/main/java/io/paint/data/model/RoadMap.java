package io.paint.data.model;

import io.paint.data.enums.MoveTo;

public record RoadMap(int speed , MoveTo moveTo) {
}

package io.paint.data.model;

import io.paint.data.enums.MoveTo;

public record Path(XY xy , MoveTo moveTo) {
}

package io.paint.data.enums;

public enum MoveTo {
    LEFT, RIGHT, TOP, BOTTOM
}

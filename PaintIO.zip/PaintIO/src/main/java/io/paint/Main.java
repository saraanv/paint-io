package io.paint;

import io.paint.controller.MainController;

public final class Main {
    public static void main(final String[] args) {
        System.out.println("Game paint");
        new MainController();
    }
}
